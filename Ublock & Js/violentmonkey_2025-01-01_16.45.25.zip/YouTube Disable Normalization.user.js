// ==UserScript==
// @name         YouTube Disable Normalization
// @namespace    https://gist.github.com/fa7ad/fa995474f5cb9fe91fb209686881373d
// @version      0.2
// @description  Allows true 100% volume on youtube videos.
// @author       Wouter Gerarts
// @match        https://www.youtube.com/*
// @match        https://youtube.com/*
// @grant        none
// ==/UserScript==

(function () {
  "use strict";

  function baseElement() {
    return document.querySelector("#content");
  }

  if (typeof fullVolumeButtonTaskId === "number") {
    console.log("clearing interval");
    clearInterval(fullVolumeButtonTaskId);
  }
  function maxVol() {
    var videos = document.querySelectorAll("video");
    videos.forEach(function (video) {
      video.volume = 1;
      console.log(video, video.volume);
    });
  }
  function createFullVolumeButton() {
    var css = `
        .full-volume-addon-button {
          margin: 0 0.5em;
          padding: 0.25em 1em;
          background: transparent;
          color: #fff;
          border: 1px solid #fff;
          border-radius: 1em;
          font: caption;
        }
        .full-volume-addon-button:hover {
          cursor: pointer;
          background: #fff;
          color: #000;
        }
        `;
    var style = document.createElement("style");
    if (style.styleSheet) {
      style.styleSheet.cssText = css;
    } else {
      style.appendChild(document.createTextNode(css));
    }
    document.querySelector("head").appendChild(style);

    var el = document.createElement("button");
    el.textContent = "100% Volume";
    el.classList.add("full-volume-addon-button");
    el.onclick = function (e) {
      e.preventDefault();
      maxVol();
    };
    return el;
  }

  function round(num, sig) {
    var mult = Math.pow(10, sig);
    return Math.round(num * mult) / mult;
  }

  var fullVolumeButtonTaskId = setInterval(function () {
    if (baseElement().querySelector("video") === undefined) {
      console.log("video element not found");
      return;
    }
    var volTimer = setInterval(function () {
      if (
        [].every.call(document.querySelectorAll("video"), function (vid) {
          return vid.volume === 1;
        })
      ) {
        console.log("vol maxed out");
        clearInterval(volTimer);
        return;
      } else {
        maxVol();
      }
    }, 500);
    if (baseElement().querySelector(".full-volume-addon-button") != undefined) {
      console.log("full volume addon button already found");
      clearInterval(fullVolumeButtonTaskId);
      clearInterval(volTimer);
      return;
    }

    var video = baseElement().querySelector("video");

    var videoTitleElement = baseElement().querySelector("#title h1");
    videoTitleElement.appendChild(createFullVolumeButton());
  }, 500);
})();
